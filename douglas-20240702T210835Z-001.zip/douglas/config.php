<?php
$dbHost = 'Localhost';
$dbUsername ='root';
$dbPassword = '';
$dbName = 'douglas';

$conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);

//if($conexao->error)
//{
 //   echo "Erro";
//}
 //else
//{
 //echo "Efetuada";
//}

?>
